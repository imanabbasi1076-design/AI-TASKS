**COMSATS University Islamabad**

**CUI Abbottabad, Dhamtour Campus**

**AI-Based Network Pathfinding & Attack Simulation System**

Course: Artificial Intelligence (CSC 262)

Instructor: Zeenat Zulfiqar \| zeenatzulfiqar@cuiatd.edu.pk

Class: BCS-4C \| Due Date: May 30, 2026

Name: Iman Nasir \| Reg no:FA24-BCS-138

# Project Files

  -----------------------------------------------------------------------
  **File**                     **Description**
  ---------------------------- ------------------------------------------
  midtermcollab.py             Main Python source code --- all 7
                               algorithms

  MIDTERMCOLLAB.ipynb          Google Colab notebook version

  cui_network_gui.html         Interactive Web GUI --- open in any
                               browser

  midterm(1)                   Overleaf report

  AICOLLAB..pdf                Auto-generated styled HTML comparison
                               table

  README.md                    This file --- setup and run instructions
  -----------------------------------------------------------------------

# Dependencies

All libraries are pre-installed in Google Collab. No installation
needed.

  -----------------------------------------------------------------------
  **Library**            **Purpose**
  ---------------------- ------------------------------------------------
  pandas                 Styled comparison table output

  heapq                  Priority queue for UCS and A\*

  time                   Execution time measurement

  json                   Network loading and result export

  collections.deque      Queue for BFS

  IPython.display        Styled table rendering in Colab
  -----------------------------------------------------------------------

If running locally (outside Colab), install pandas:

pip install pandas

All other libraries are Python built-ins --- no extra installation
needed.

# How to Run

## Option 1 --- Google Colab (Recommended)

• Go to colab.research.google.com

• Upload MIDTERMCOLLAB.ipynb

-   Choose Runtime → Run All

-   All 7 algorithms are performed automatically.

-   The comparison table is styled, and it will display at the bottom.

-   These files: simulation_results.json and simulation_report.html are
    saved in the session.

## Option 2 --- Run Locally

Python midtermcollab.py

## Option 3 --- Web GUI (No Python needed)

-   Open cui_network_gui.html in any browser (Chrome is recommended)

-   Choose any Algorithm button in the right pane

-   Observe the attack route get animated one step at a time, on the
    network graph.

-   See metrics and compare all metrics at bottom.

-   Visualize any algorithm by clicking a row in any table.

# Network Configuration

  -----------------------------------------------------------------------
  **Property**           **Value**
  ---------------------- ------------------------------------------------
  Total Nodes            10

  Total Edges            11

  Start Node             Student_Lab --- Attacker Entry Point

  Goal Node              Admin_Database --- Target Critical Asset

  Edge Weights           Represent vulnerability / traversal risk cost

  Loading                Dynamic --- JSON file or source code fallback
  -----------------------------------------------------------------------

## Network Nodes

  ---------------------------------------------------------------------------
  **Node**                 **Type**           **Role**
  ------------------------ ------------------ -------------------------------
  Student_Lab              Workstation        Start --- Attacker Entry Point

  WiFi_Router              Network Device     Campus wireless hub

  Firewall                 Security Device    Network perimeter guard

  Library_Server           Server             Academic resource server

  Faculty_Portal           Web Server         Faculty management portal

  Fee_Server               Financial Server   Financial transactions server

  Backup_System            Storage            Data backup node

  Admin_PC                 Workstation        Administrator workstation

  Security_Camera_System   IoT / Surveillance Campus surveillance system

  Admin_Database           Database           Goal --- Target Critical Asset
  ---------------------------------------------------------------------------

# Algorithms Implemented

  -----------------------------------------------------------------------------------
  **\#**   **Algorithm**   **Type**       **Depth**   **Goal Reached**
  -------- --------------- -------------- ----------- -------------------------------
  1        BFS             Uninformed     ---         Yes

  2        DFS             Uninformed     ---         Yes

  3        UCS             Informed       ---         Yes

  4        A\*             Informed       ---         Yes

  5        Hill Climbing   Local Search   ---         No --- Stuck at Faculty_Portal

  6        Minimax         Adversarial    8           Yes

  7        Alpha-Beta      Adversarial    8           Yes
           Pruning                                    
  -----------------------------------------------------------------------------------

# Results Summary

  -------------------------------------------------------------------------
  **Algorithm**     **Cost**   **Nodes           **Status**
                               Expanded**        
  ----------------- ---------- ----------------- --------------------------
  BFS               16         9                 SUCCESS

  DFS               16         10                SUCCESS

  UCS               16         9                 SUCCESS

  A\*               16         5                 SUCCESS

  Hill Climbing     N/A        4                 STUCK --- Local Maxima

  Minimax           16         35                SUCCESS

  Alpha-Beta        16         23                SUCCESS
  -------------------------------------------------------------------------

All successful algorithms found the same optimal path:

Student_Lab → WiFi_Router → Firewall → Admin_PC → Admin_Database (Cost =
16)

# Key Design Decisions

## Heuristic for A\*

The estimated risk-distance to Admin_Database is expressed by h(n). Goal
node is h=0; value of nodes increases as farther from goal. Admissible
heuristic --- will never overestimate the actual cost and A\* will
determine the best path.

## Hill Climbing Local Maxima Demo

In the demo heuristic, the faculty member is assigned the value of h=2,
which forms an artificial trap. The algorithm approaches it, believing
it has arrived at \"the end\", but ultimately fails to improve anymore.
This illustrates the local maxima problem in Hill Climbing..

## Minimax Adversarial Model

-   Attacker = Maximizer --- goal reward = 1000

-   Defender = Minimizer --- blocks forward neighbor nodes via
    secured_nodes set

-   Depth = 8 --- required for full path discovery to Admin_Database

## Alpha-Beta Pruning

Reduced node expansions from 35 to 23 (a 34% efficiency gain) compared
to a Minimax, by removing branches where beta is less than or equal
alpha. This correctly plays out the speed boost from standard Minimax as
specified by the project.

# Submission Checklist

-   Google Colab .ipynb notebook file

-   Python .py source code

-   PDF of code (exported from Colab)

-   cui_network_gui.html --- Interactive Web GUI

-   Overleaf report link

-   PDF of report (downloaded from Overleaf)

-   README.md
